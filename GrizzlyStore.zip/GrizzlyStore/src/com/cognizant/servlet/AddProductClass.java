package com.cognizant.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.dao.ProductDAO;
import com.cognizant.entity.Product;
import com.cognizant.helper.FactoryProductDAO;

/**
 * Servlet implementation class AddProductClass
 */
@WebServlet(name = "AddProduct", urlPatterns = { "/addproduct" })
public class AddProductClass extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddProductClass() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int productId=Integer.parseInt(request.getParameter("productId"));
        String productName=request.getParameter("productName");
        String productCategory=request.getParameter("productCategory");
        int productPrice=Integer.parseInt(request.getParameter("productPrice"));
        String productBrand=request.getParameter("productBrand");
    	ProductDAO productDAO=FactoryProductDAO.createProductDAO();
		boolean productExists=productDAO.checkProduct(productId);
		
		if(!productExists)
		{
			Product product=new Product();
			product.setProductID(productId);
			product.setProductName(productName);
			product.setProductCategory(productCategory);
			product.setProductPrice(productPrice);
			product.setProductBrand(productBrand);
			boolean result=productDAO.addProduct(product);
			
			if(result)
			{
				response.getWriter().println("Product Added !!!");
			}
			else
			{
				response.getWriter().println("Product Was Not Added");
			}
			
		}
		else
		{
			response.getWriter().println("Product Already Exists !!!!!");
		}
		ServletContext sc = this.getServletContext();
		RequestDispatcher rd = sc.getRequestDispatcher("/WelcomeAdmin.jsp");
		rd.forward(request, response);
	}

	}

