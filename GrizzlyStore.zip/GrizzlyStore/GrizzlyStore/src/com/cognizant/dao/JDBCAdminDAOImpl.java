package com.cognizant.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cognizant.helper.ConnectionManager;

public class JDBCAdminDAOImpl implements AdminDAO{

	private ConnectionManager manager=new ConnectionManager();
	 
	@Override
	public boolean authAdmin(String username, String password) {
		// TODO Auto-generated method stub
		Connection connection=manager.openConnection();
		boolean result=false;
		
		PreparedStatement statement;
		try {
			statement = connection.prepareStatement("select * from USERDATA where USER_NAME=? and PASSWORD=?");
			statement.setString(1,username);
			statement.setString(2,password);
			ResultSet resultSet=statement.executeQuery();
			while(resultSet.next())
			{
				result=true;
			}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	}
	
	

}
